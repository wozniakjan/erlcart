defmodule Bat do
  ThisModuleWillNeverBeAvailable[]
end