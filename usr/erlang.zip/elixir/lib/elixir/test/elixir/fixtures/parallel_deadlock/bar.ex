defmodule Bar do
  Foo.__info__(:macros)
end