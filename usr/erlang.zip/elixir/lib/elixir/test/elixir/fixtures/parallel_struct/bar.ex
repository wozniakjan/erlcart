defmodule Bar do
  defstruct name: ""
  def foo?(%Foo{}), do: true
end
