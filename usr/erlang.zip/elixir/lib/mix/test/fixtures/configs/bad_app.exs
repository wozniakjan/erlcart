[sample: :oops]
